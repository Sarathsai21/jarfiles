package com.capgemini.truckbooking.client;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exceptions.BookingExceptions;
import com.capgemini.truckbooking.service.ITruckService;
import com.capgemini.truckbooking.service.TruckService;



public class BookingClient {

	

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		String custID= "";
		boolean result = false;
		try {
			result = ITruckService.validateFields(custID);
		} catch (BookingExceptions e1) {
			System.out.println("Please provide a proper customer Id");
		}

		do {
		System.out.println("===============Transport Truck Booking====================");
		System.out.println("1.Book Trucks");
		System.out.println("2.Exit");

		System.out.println("Enter the Choice");
		int choice = scanner.nextInt();

		switch (choice) {
		case 1:

			System.out.println("Enter the Customer ID");
			custID = scanner.nextLine();

			
			DateTimeFormatter dateTimeFormatter = null;
			boolean dateFlag = false;
			ITruckService iTruckService = new TruckService();
			List<TruckBean> list = new ArrayList<>(); 
					

			
			try {
				list = iTruckService.retriveTruckDetails(custID);
				System.out.println("TruckId" + "TruckType" + "origin" + "destination" + "charge" + "AvailableNos");
				
				
			} catch (BookingExceptions e1) {
				System.out.println("No details Found");
			}
			
			
			BookingBean bookingBean = new BookingBean();
			
			
			
			 try {
				int bookingNo= iTruckService.bookTrucks(bookingBean);
			} catch (BookingExceptions e) {
				System.out.println("");
			}
			
		
			

			
			break;

		case 2:
			System.out.println(" Thank You ");

			break;

		default:
			
			System.out.println("Enter a Valid choice from the Menu list");
			break;
		}
		}while (result == true);
	}

}
