package com.capgemini.truckbooking.dao;

public interface QueryMapper {
	
	public static final String truckDetails= "select * from truckDetails where custId = ?";
	
	
	public static final String insertQuery = "insert into bookingDeatils values(booking_id_sequence,?,?,?,?)";
	
	 
	
	
	

}
