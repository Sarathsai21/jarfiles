package com.capgemini.truckbooking.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.exceptions.BookingExceptions;
import com.capgemini.truckbooking.service.ITruckService;
import com.capgemini.truckbooking.service.TruckService;

/*public class TruckDao{

	PreparedStatement statement = null;
	//Connection connection = null;

	//ResultSet resultSet = null;
	connection=JdbcUtility.getConnection();

	
		statement = connection.prepareStatement(QueryMapper.truckDetails);
	

	List<BookingBean> list = new ArrayList<>();
	

}
*/