package com.capgemini.truckbooking.dao;

import java.util.List;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exceptions.BookingExceptions;

public interface ITruckDao {

	
	int getBookingId() throws BookingExceptions;
	
	
	List<TruckBean> retrieveTruckDetails() throws BookingExceptions;
	
	
	
	int bookTrucks(BookingBean bookingBean) throws BookingExceptions;

	
	
	
}
