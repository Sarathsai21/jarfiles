package com.capgemini.truckbooking.service;

import java.util.List;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exceptions.BookingExceptions;

public class TruckService implements ITruckService {

	ITruckService iTruckService = new TruckService();

	@Override
	public List<TruckBean> retriveTruckDetails(String custID) throws BookingExceptions {

		return iTruckService.retriveTruckDetails(custID);
	}

	
	@Override
	public int bookTrucks(BookingBean bookingBean) throws BookingExceptions {

		return iTruckService.bookTrucks(bookingBean);
	}

}
