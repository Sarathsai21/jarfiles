package com.capgemini.truckbooking.service;

import java.util.List;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exceptions.BookingExceptions;

public interface ITruckService {

	static boolean validateFields(String custID)  throws BookingExceptions{
		
		
		
				return false;
				
				
				
				
	}

	

	List<TruckBean> retriveTruckDetails(String custID) throws BookingExceptions;

	int bookTrucks(BookingBean bookingBean) throws BookingExceptions;
	
	
	

}
