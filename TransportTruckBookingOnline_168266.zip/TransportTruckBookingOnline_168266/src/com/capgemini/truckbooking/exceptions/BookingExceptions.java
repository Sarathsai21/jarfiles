package com.capgemini.truckbooking.exceptions;

public class BookingExceptions extends Exception {
	public BookingExceptions(String message) {

		super(message);
	}

}
